package com.customer.detailc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DetailcApplicationTests {

	@Test
	void contextLoads() {
	}

}
