package com.customer.detailc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DetailcApplication {

	public static void main(String[] args) {
		SpringApplication.run(DetailcApplication.class, args);
	}

}
